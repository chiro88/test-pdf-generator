from __future__ import annotations

from typing import List

from .layout import band
from .models import (
    CaseSpec,
    FigureSpec,
    HeaderFooterSpec,
    NegativeTextSpec,
    PageSpec,
    TableSpec,
    WatermarkSpec,
)
from .templates import FOOTER_TEMPLATES, HEADER_TEMPLATES, WATERMARK_TEMPLATES


def _hf_header(rule: bool = True, mirrored: bool = False, support_pages=None) -> HeaderFooterSpec:
    return HeaderFooterSpec(
        enabled=True,
        bbox=band(48, 18, 564, 54),
        text_template=HEADER_TEMPLATES["subtitle_page"],
        variable_text=True,
        mirrored_even_odd=mirrored,
        rule_line=rule,
        support_pages=support_pages,
    )


def _hf_footer(rule: bool = True, mirrored: bool = False, support_pages=None) -> HeaderFooterSpec:
    return HeaderFooterSpec(
        enabled=True,
        bbox=band(48, 740, 564, 774),
        text_template=FOOTER_TEMPLATES["confidential_page"],
        variable_text=True,
        mirrored_even_odd=mirrored,
        rule_line=rule,
        support_pages=support_pages,
    )


def core_cases() -> List[CaseSpec]:
    return [
        CaseSpec(
            case_id="core_fixed_header_footer",
            axes={"core": "fixed_header_footer", "header_footer": "both_fixed", "pages": 3, "columns": "single"},
            page=PageSpec(page_count=3),
            header=HeaderFooterSpec(True, band(48, 18, 564, 54), HEADER_TEMPLATES["plain"], False, False, True),
            footer=HeaderFooterSpec(True, band(48, 740, 564, 774), FOOTER_TEMPLATES["plain"], False, False, True),
            notes="Fixed header and footer appear on every page with stable y-bands.",
        ),
        CaseSpec(
            case_id="core_variable_subtitle_header",
            axes={"core": "variable_subtitle_header", "header_footer": "header_variable_subtitle", "pages": 3, "page_offset": 10},
            page=PageSpec(page_count=3, page_offset=10),
            header=_hf_header(rule=True, mirrored=True),
            notes="Header keeps stable position but text varies by page/subtitle and even/odd mirroring.",
        ),
        CaseSpec(
            case_id="core_fixed_watermark",
            axes={"core": "fixed_watermark", "watermark": "center_rot45_fixed", "pages": 1},
            page=PageSpec(page_count=1),
            watermark=WatermarkSpec(True, band(140, 300, 470, 500), WATERMARK_TEMPLATES["confidential"], False, 45, 0.16, "center"),
            notes="Centered diagonal fixed text watermark.",
        ),
        CaseSpec(
            case_id="core_figure_caption_bottom",
            axes={"core": "figure_caption_bottom", "figure": "caption_below_body", "index": "3.4", "body": "waveform"},
            page=PageSpec(page_count=1),
            figures=(FigureSpec("3.4", "Waveform timing relationship", band(54, 492, 558, 520), band(54, 210, 558, 485), "waveform", "Figure", "below"),),
            notes="Figure body above caption; expected figure_body_direction=up.",
        ),
        CaseSpec(
            case_id="core_figure_caption_top",
            axes={"core": "figure_caption_top", "figure": "caption_above_body", "index": "A.1", "body": "diagram"},
            page=PageSpec(page_count=1),
            figures=(FigureSpec("A.1", "Reset path block diagram", band(54, 126, 558, 154), band(54, 165, 558, 430), "diagram", "Fig.", "above"),),
            notes="Figure caption above body; alpha index protects ID formatting regressions.",
        ),
        CaseSpec(
            case_id="core_multipage_table_cont",
            axes={"core": "multipage_table_cont", "table": "continuation_3parts", "suffix": "(cont)", "pages": 3},
            page=PageSpec(page_count=3),
            header=_hf_header(),
            footer=_hf_footer(),
            tables=(
                TableSpec("2.1", "Register map", band(54, 90, 558, 118), band(54, 128, 558, 710), "tbl_002_001", 1, False, None, 1),
                TableSpec("2.1", "Register map", band(54, 90, 558, 118), band(54, 128, 558, 710), "tbl_002_001", 2, True, "(cont)", 2, "tbl_002_001"),
                TableSpec("2.1", "Register map", band(54, 90, 558, 118), band(54, 128, 558, 710), "tbl_002_001", 3, True, "(cont)", 3, "tbl_002_001"),
            ),
            notes="Three-page table continuation with identical title and continuation suffix.",
        ),
        CaseSpec(
            case_id="core_same_title_tables",
            axes={"core": "same_title_tables", "table": "same_title_distinct_groups", "pages": 1},
            page=PageSpec(page_count=1),
            tables=(
                TableSpec("4.2", "Electrical characteristics", band(54, 96, 558, 120), band(54, 130, 558, 310), "tbl_004_002_a", page=1, rows=5),
                TableSpec("4.2", "Electrical characteristics", band(54, 390, 558, 414), band(54, 424, 558, 650), "tbl_004_002_b", page=1, rows=6),
            ),
            notes="Two separate tables with the same visible title on the same page.",
        ),
        CaseSpec(
            case_id="core_wide_diagram_xrange",
            axes={"core": "wide_diagram_xrange", "figure": "wide_page_body", "columns": "two"},
            page=PageSpec(columns=2),
            figures=(FigureSpec("2-7", "Page-wide datapath overview", band(54, 500, 558, 528), band(40, 170, 572, 492), "mixed", "FIGURE", "below"),),
            notes="Page-wide figure across a two-column text texture; stresses x-range envelope.",
        ),
    ]


def negative_cases() -> List[CaseSpec]:
    return [
        CaseSpec(
            case_id="neg_plain_text_only",
            axes={"negative": "ordinary_text_no_regions", "pages": 1},
            page=PageSpec(page_count=1),
            realistic=True,
            notes="Plain engineering prose page with no common regions, figures, or tables.",
        ),
        CaseSpec(
            case_id="neg_false_figure_of_merit",
            axes={"negative": "figure_of_merit_phrase"},
            page=PageSpec(page_count=1),
            negative_texts=(NegativeTextSpec("Figure of merit is defined as the ratio of useful output to input power. This is not a caption.", band(70, 160, 540, 230)),),
            notes="Contains 'Figure' at sentence start but no figure object.",
        ),
        CaseSpec(
            case_id="neg_false_see_table_above",
            axes={"negative": "see_table_above_phrase"},
            page=PageSpec(page_count=1),
            negative_texts=(NegativeTextSpec("For configuration details, see Table above in the previous section. No table appears on this page.", band(70, 240, 540, 310)),),
            notes="Contains table-like wording but no table title/body.",
        ),
        CaseSpec(
            case_id="neg_caption_reference_only",
            axes={"negative": "caption_reference_only"},
            page=PageSpec(page_count=1),
            negative_texts=(NegativeTextSpec("Figure 3.4 is referenced for historical context only; the actual diagram is not reproduced here.", band(70, 180, 540, 260)),),
            notes="Looks like a caption prefix but is an inline reference only.",
        ),
        CaseSpec(
            case_id="neg_weak_partial_header",
            axes={"negative": "weak_partial_header", "header_footer": "partial_support"},
            page=PageSpec(page_count=3),
            header=HeaderFooterSpec(True, band(48, 18, 564, 54), HEADER_TEMPLATES["subtitle_page"], True, False, False, support_pages=[1]),
            notes="Header-like text appears on only one of three pages; should test min support ratio behavior.",
        ),
    ]


def expanded_cases() -> List[CaseSpec]:
    cases: List[CaseSpec] = []
    # Small but useful v0 expansion. cc handoff spec requires expanding this to 30-50 cases.
    cases.append(CaseSpec(
        case_id="exp_a4_landscape_footer_only_wm_corner",
        axes={"page_size": "a4", "orientation": "landscape", "footer": "only", "watermark": "corner_image_like"},
        page=PageSpec(size="a4", orientation="landscape", page_count=1),
        footer=HeaderFooterSpec(True, band(54, 520, 788, 555), FOOTER_TEMPLATES["doc_rev_page"], True, False, True),
        watermark=WatermarkSpec(True, band(585, 70, 780, 180), WATERMARK_TEMPLATES["draft"], False, 0, 0.12, "corner", True),
        notes="A4 landscape with footer-only common region and corner image-like watermark.",
    ))
    cases.append(CaseSpec(
        case_id="exp_two_column_multi_figures",
        axes={"columns": "two", "figure": "multiple_per_page", "labels": "Figure_and_Fig"},
        page=PageSpec(columns=2),
        figures=(
            FigureSpec("12", "Column-local waveform", band(54, 280, 286, 306), band(54, 140, 286, 272), "waveform", "Figure", "below"),
            FigureSpec("A.1", "Column-local raster map", band(326, 280, 558, 306), band(326, 140, 558, 272), "raster", "Fig.", "below"),
        ),
        notes="Two figures on one two-column page with different aliases and index styles.",
    ))
    cases.append(CaseSpec(
        case_id="exp_table_suffix_continued_lower",
        axes={"table": "continuation_2parts", "suffix": "continued"},
        page=PageSpec(page_count=2),
        tables=(
            TableSpec("5.3", "Timing limits", band(54, 110, 558, 136), band(54, 145, 558, 700), "tbl_005_003", 1, False, None, 1),
            TableSpec("5.3", "Timing limits", band(54, 110, 558, 136), band(54, 145, 558, 700), "tbl_005_003", 2, True, "continued", 2, "tbl_005_003"),
        ),
        notes="Continuation suffix uses lowercase 'continued'.",
    ))
    cases.append(CaseSpec(
        case_id="exp_table_suffix_cont_dot",
        axes={"table": "continuation_2parts", "suffix": "cont."},
        page=PageSpec(page_count=2),
        tables=(
            TableSpec("6.1", "Pin configuration", band(54, 100, 558, 126), band(54, 136, 558, 700), "tbl_006_001", 1, False, None, 1),
            TableSpec("6.1", "Pin configuration", band(54, 100, 558, 126), band(54, 136, 558, 700), "tbl_006_001", 2, True, "cont.", 2, "tbl_006_001"),
        ),
        notes="Continuation suffix uses 'cont.' punctuation.",
    ))
    cases.append(CaseSpec(
        case_id="exp_caption_above_table_wide",
        axes={"table": "single_page_wide", "caption": "above", "width": "wide"},
        page=PageSpec(page_count=1),
        tables=(TableSpec("7.9", "Wide timing matrix", band(36, 105, 576, 130), band(36, 140, 576, 430), "tbl_007_009", rows=7, cols=7),),
        notes="Wide table with title above body.",
    ))
    cases.append(CaseSpec(
        case_id="exp_variable_watermark_email",
        axes={"watermark": "variable_email_rot45", "pages": 3},
        page=PageSpec(page_count=3),
        watermark=WatermarkSpec(True, band(120, 310, 500, 510), WATERMARK_TEMPLATES["licensed"], True, -45, 0.12, "center"),
        notes="Variable email watermark text at stable position across pages.",
    ))
    return cases


def all_cases() -> List[CaseSpec]:
    return core_cases() + negative_cases() + expanded_cases()
