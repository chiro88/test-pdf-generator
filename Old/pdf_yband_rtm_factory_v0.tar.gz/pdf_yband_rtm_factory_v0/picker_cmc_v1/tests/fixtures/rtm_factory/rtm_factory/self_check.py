from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Iterable, Tuple

import fitz

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def _bbox_ok(bbox, width: float, height: float) -> bool:
    return (
        isinstance(bbox, list)
        and len(bbox) == 4
        and 0 <= bbox[0] < bbox[2] <= width
        and 0 <= bbox[1] < bbox[3] <= height
    )


def _iter_region_bboxes(page: dict) -> Iterable[Tuple[str, list]]:
    for region in page.get("common_regions", []):
        yield region.get("kind", "common"), region["bbox"]
    for fig in page.get("figures", []):
        yield "figure.caption_region", fig["caption_region"]
        yield "figure.body_region", fig["body_region"]
        yield "figure.context_region", fig["context_region"]
    for tbl in page.get("tables", []):
        yield "table.caption_region", tbl["caption_region"]
        yield "table.body_region", tbl["body_region"]
        if "context_region" in tbl:
            yield "table.context_region", tbl["context_region"]


def _check_case(case_dir: Path) -> list[str]:
    errors: list[str] = []
    case_id = case_dir.name
    pdf_path = case_dir / f"{case_id}.pdf"
    truth_path = case_dir / f"{case_id}.truth.json"
    notes_path = case_dir / f"{case_id}.notes.md"
    if not pdf_path.exists():
        errors.append(f"{case_id}: missing PDF")
        return errors
    if not truth_path.exists():
        errors.append(f"{case_id}: missing truth.json")
        return errors
    if not notes_path.exists() or not notes_path.read_text(encoding="utf-8").strip():
        errors.append(f"{case_id}: missing or empty notes.md")

    truth = json.loads(truth_path.read_text(encoding="utf-8"))
    try:
        doc = fitz.open(str(pdf_path))
    except Exception as exc:  # pragma: no cover - diagnostic path
        errors.append(f"{case_id}: PDF open failed: {exc}")
        return errors
    if doc.page_count != len(truth.get("pages", [])):
        errors.append(f"{case_id}: page_count mismatch pdf={doc.page_count} truth={len(truth.get('pages', []))}")
    for i in range(doc.page_count):
        png_path = case_dir / f"{case_id}.p{i + 1:02d}.png"
        if not png_path.exists() or not png_path.read_bytes().startswith(PNG_MAGIC):
            errors.append(f"{case_id}: missing/bad png {png_path.name}")
    for page in truth.get("pages", []):
        width = page["width"]
        height = page["height"]
        for label, bbox in _iter_region_bboxes(page):
            if not _bbox_ok(bbox, width, height):
                errors.append(f"{case_id}: invalid bbox {label}={bbox} for {width}x{height}")
    # Coordinate convention sanity: any top common header should be in upper half.
    for page in truth.get("pages", []):
        for reg in page.get("common_regions", []):
            if reg.get("kind") == "header" and reg["bbox"][1] >= page["height"] / 2:
                errors.append(f"{case_id}: header is not top-left y convention? bbox={reg['bbox']}")
    doc.close()
    return errors


def run_self_check(gallery_dir: Path) -> None:
    manifest_path = gallery_dir / "MANIFEST.json"
    index_path = gallery_dir / "index.md"
    if not manifest_path.exists():
        raise AssertionError("MANIFEST.json missing")
    if not index_path.exists():
        raise AssertionError("index.md missing")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    case_ids = [case["case_id"] for case in manifest.get("cases", [])]
    errors: list[str] = []
    for case_id in case_ids:
        errors.extend(_check_case(gallery_dir / case_id))

    index_text = index_path.read_text(encoding="utf-8")
    for required in ["realism 1-5", "keep/drop", "critique"]:
        if required not in index_text:
            errors.append(f"index.md missing evaluation column: {required}")
    for case_id in case_ids:
        if case_id not in index_text:
            errors.append(f"index.md missing case: {case_id}")

    axes_counter = Counter()
    negative_count = 0
    core_count = 0
    for case in manifest.get("cases", []):
        axes = case.get("axes", {})
        for key, value in axes.items():
            axes_counter[f"{key}={value}"] += 1
        if "negative" in axes:
            negative_count += 1
        if "core" in axes:
            core_count += 1
    if core_count < 8:
        errors.append(f"core scenario count too low: {core_count}")
    if negative_count < 5:
        errors.append(f"negative scenario count too low: {negative_count}")

    if errors:
        raise AssertionError("RTM factory self-check failed:\n" + "\n".join(errors))
