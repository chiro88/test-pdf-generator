A4 landscape with footer-only common region and corner image-like watermark.
