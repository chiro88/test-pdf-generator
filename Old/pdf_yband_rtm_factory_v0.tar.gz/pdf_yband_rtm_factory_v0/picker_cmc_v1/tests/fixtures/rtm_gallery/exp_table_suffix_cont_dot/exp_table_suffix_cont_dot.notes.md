Continuation suffix uses 'cont.' punctuation.
