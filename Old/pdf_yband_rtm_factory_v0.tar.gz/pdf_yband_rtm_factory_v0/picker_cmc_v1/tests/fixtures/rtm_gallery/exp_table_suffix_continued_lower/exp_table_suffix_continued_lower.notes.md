Continuation suffix uses lowercase 'continued'.
