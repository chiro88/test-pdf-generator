Variable email watermark text at stable position across pages.
